package com.net;

import java.awt.BorderLayout;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.tictactalk.Game;
import com.tictactalk.Index;
import com.tictactalk.MainFrame;

public class Client extends Thread {
    public static BufferedWriter bw;
    public static BufferedReader br;
    private static Game gameInstance;
    public static String playerId;
    public static String enemyId;
    private Socket sock;

    @Override
    public void run() {
        InputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        ConnectDb db=new ConnectDb();
        db.connectDb();
        System.out.println("[Client] DB connect ok. 전적 수:" + ConnectDb.map.size());
        try {
            InetAddress addr = InetAddress.getByAddress(new byte[] { (byte) 172, 30, 1, 2 });
            sock = new Socket(addr, 3000);

            OutputStream os = sock.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            bw = new BufferedWriter(osw);
            //로그인 ID 서버에 전송
            bw.write("id:"+playerId);
            bw.newLine();
            bw.flush();
            
            is = sock.getInputStream();
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);

            while (true) {
                String msg;
                while ((msg = br.readLine()) != null) {
                    executeCommand(msg);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void executeCommand(String msg) {
    	if(msg.startsWith("enemy:")) {
    		enemyId = msg.substring(msg.indexOf(":")+1);
    		System.out.println("[상대 ID] "+enemyId);
    		return;
    	}
    	
        if (msg.equals("call")) {
            System.out.println("게임 시작!");
            SwingUtilities.invokeLater(() -> {
            	boolean isMyTurn = playerId.compareTo(enemyId)<0;	//내 턴일 때만
            	Game game = new Game(isMyTurn) {			//playerId, enemyId, map 넣어진 이후 객체 생성
            		@Override
					public void onGameEnd(String result) {
            			Client.sendGameResult(result);
					}
            	};
            	MainFrame.cardPanel.add(game,"Game");
            	MainFrame.switchTo("Game");				//게임 화면으로 전환
            	Client.setGameInstance(game);
            	game.updatePlayerPanels();
            	
            	if(Index.getInstance().loadingDialog !=null) {
            		Index.getInstance().loadingDialog.dispose();
            	}
            });
            return;
        } 
        
        if(msg.startsWith("move:")) {
        	String[] parts = msg.split(":");
        	int x=Integer.parseInt(parts[1]);
        	int y=Integer.parseInt(parts[2]);
        	
        	if(gameInstance != null) {
        		SwingUtilities.invokeLater(() -> {
        			gameInstance.markOpponentMove(x, y);
        			System.out.println("[상대 수] "+x+","+y);
        		});
        	}
        	return;
        }
        gameInstance.appendChat(msg);
    }
    
    public static void setGameInstance(Game game) {
    	gameInstance = game;
    }

    public static void sendGameResult(String result) {
        try {
            if (bw != null) {
                bw.write("result:" + result);
                bw.newLine();
                bw.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeIO() {
    	try {
    		if(bw !=null) bw.close();
    		if(sock !=null) sock.close();
    	}catch (IOException e) {
    		e.printStackTrace();
    	}
    }

    public static void main(String[] args) {
        Client client = new Client();
        playerId = com.tictactalk.Index.id; 
        client.start();
    }

	public static void sendMessage(String string) {
		try {
			if(bw!=null) {
				bw.write(string);
				bw.newLine();
				bw.flush();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}