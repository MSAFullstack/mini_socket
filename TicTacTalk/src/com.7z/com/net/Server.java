package com.net;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class Server {
	static ServerSocket serverSocket;
    static List<BufferedWriter> chat = new ArrayList<>();
    static Map<String, BufferedWriter> userMap = new HashMap<>();
    static Map<String, String> enemyMap = new HashMap<>();
    static Map<String, Socket> socketMap = new HashMap<>();
    static Map<Socket, String> playerIds=new HashMap<>();
    static Queue<Socket> waitingList = new LinkedList<>();
    
    private static void processGameResult(String id, String result) {
    	System.out.println("[���� ��� ó��]"+id+"-"+result);
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "scott";
        String password = "tiger";
        
        List<String> validResults = Arrays.asList("win","draw","lose");
        if (!validResults.contains(result)) {
        	System.out.println("[����] ��ȿ���� ���� �����: "+result);
        	return;
        }
        
        String sql="update TTTDB set "+result+" = "+result+" + 1 where id=?";
        
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, user, password);
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, id);
            int updated = stmt.executeUpdate();
            if(updated>0) {
            	System.out.println("[DB ������Ʈ ����] "+id+"- "+result);
            }else {
            	System.out.println("[DB ������Ʈ ����] ����� ID ����: "+id);
            }
        } catch (ClassNotFoundException | SQLException e) {
        	System.out.println("[DB ����] " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
        	serverSocket = new ServerSocket(3000);

            while (true) {
                Socket sock = serverSocket.accept();
                new Thread(() -> handleClient(sock)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	private static Object handleClient(Socket sock) {
		try {
			BufferedReader br=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			
			String idLine = br.readLine();
			String id= idLine.substring(idLine.indexOf(":")+1);
			userMap.put(id,bw);
			socketMap.put(id, sock);
			playerIds.put(sock, id);
			chat.add(bw);
			waitingList.add(sock);
			System.out.println("[나]"+id);
			
			//2명 이상 접속일 때 게임 시작 사인 call 보내기
			if(waitingList.size()>=2) {
				Socket s1=waitingList.poll();
				Socket s2=waitingList.poll();
				
				String id1=playerIds.get(s1);
				String id2=playerIds.get(s2);
				
				BufferedWriter out1 = userMap.get(id1);
				BufferedWriter out2 = userMap.get(id2);
				
				enemyMap.put(id1, id2);
				enemyMap.put(id2, id1);
				
				out1.write("enemy: "+id2);
				out2.write("enemy: "+id1);
				out1.newLine();
				out2.newLine();
				out1.flush();
				out2.flush();
				
				out1.write("call");
				out2.write("call");
				out1.newLine();
				out2.newLine();
				out1.flush();
				out2.flush();
			}
			
			String msg;
			while((msg=br.readLine())!=null) {
				String senderId = playerIds.get(sock);
				System.out.println("["+senderId+"]"+msg);
				
				if(msg.startsWith("move:")) {
					String enemyId=enemyMap.get(senderId);
					BufferedWriter enemyWriter = userMap.get(enemyId);
					if(enemyWriter !=null) {
						enemyWriter.write(msg);
						enemyWriter.newLine();
						enemyWriter.flush();
					}
					continue;
				}
				if(msg.startsWith("result:")) {
					String[] parts = msg.split(":");
					if(parts.length==2) {
						String result=parts[1];
						processGameResult(senderId, result);
					}
					continue;
				}
				for(BufferedWriter writer : chat) {
					writer.write(senderId+": "+msg);
					writer.newLine();
					writer.flush();
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		
	}
}