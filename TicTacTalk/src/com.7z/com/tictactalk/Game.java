package com.tictactalk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import com.net.Client;
import com.net.ConnectDb;

public class Game extends JPanel implements ActionListener {
    private JButton[][] buttons = new JButton[3][3];
    private boolean isPlayerOneTurn = true;
    private JTextArea chatArea;
    private JTextField chatInput;
    private JButton sendButton;
    private JLabel statusLabel;
    private JLabel timerLabel;
    private boolean isMyTurn;
    private JPanel playerInfoPanel;

    private String mySymbol;
    private String enemySymbol;
    
    public Game(boolean isMyTurn) {
    	this.isMyTurn=isMyTurn;
        setLayout(new BorderLayout());
        setBackground(Color.decode("#4ED59B"));
        
        //X/O 역할 분담
        if(Client.playerId.compareTo(Client.enemyId)<0) {
        	mySymbol="X";
        	enemySymbol="O";
        }else {
        	mySymbol="O";
        	enemySymbol="X";
        }

        // 게임판 (전체의 2/3)
        JPanel boardPanel = new JPanel(new GridLayout(3, 3));
        boardPanel.setPreferredSize(new Dimension(550, 550));
        Font font = new Font("Arial", Font.BOLD, 60);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
            	final int row=i;
            	final int col=j;
                buttons[i][j] = new JButton("");
                buttons[i][j].setFont(font);
                buttons[i][j].addActionListener(e->{
                	if(!this.isMyTurn || !buttons[row][col].getText().equals("")) return;
                	buttons[row][col].setText("X");
                	System.out.println("[내 수] "+row+","+col);
                	this.isMyTurn = false;
                	statusLabel.setText("상대 턴입니다.");
                	//서버에 수 전송
                	Client.sendMessage("move:"+row+":"+col);
                });
                boardPanel.add(buttons[i][j]);
            }
        }

        // 오른쪽 전체(플레이어 정보+채팅)
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setPreferredSize(new Dimension(280, 700));

        // 상단: 플레이어 전적 정보(초기 빈 패널)
        playerInfoPanel = new JPanel(new GridLayout(1, 2));
        playerInfoPanel.setMaximumSize(new Dimension(280, 140));
        playerInfoPanel.add(new JPanel());
        playerInfoPanel.add(new JPanel());

        // 중간: 채팅창
        JPanel chatPanel = new JPanel(new BorderLayout());
        chatPanel.setPreferredSize(new Dimension(260, 400));
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        chatInput = new JTextField();
        sendButton = new JButton("전송");
        
        //게임판과는 별도인 채팅창을 위한 리스너 코드
        sendButton.addActionListener(e-> {
        	String message = chatInput.getText().trim();
        	if(!message.isEmpty()) {
        		Client.sendMessage(Client.playerId+": "+message);
        		chatInput.setText("");
        	}
        });

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(chatInput, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        chatPanel.add(scrollPane, BorderLayout.CENTER);
        chatPanel.add(inputPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        chatInput.addActionListener(e -> sendMessage());

        // 상태, 시간 표시
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel(isMyTurn? "내 턴입니다.":"상대 턴입니다.", JLabel.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel = new JLabel("남은 시간 : 60초", SwingConstants.RIGHT);
        timerLabel.setForeground(Color.RED);
        statusPanel.add(statusLabel, BorderLayout.CENTER);
        statusPanel.add(timerLabel, BorderLayout.EAST);

        rightPanel.add(playerInfoPanel);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(chatPanel);
        rightPanel.add(Box.createVerticalStrut(10));

        add(boardPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
        add(statusPanel, BorderLayout.SOUTH);

    }
    
    private void handleLocalMove(int row, int col) {
    	buttons[row][col].setText(isPlayerOneTurn ? "X" :"O");
    	if(checkWin()) {
    		statusLabel.setText((isPlayerOneTurn ? Client.playerId : Client.enemyId) + "승리!");
    		disableBoard();
    		Client.sendGameResult(isPlayerOneTurn ? "win" : "lose");
    	} else if (isBoardFull()) {
    		statusLabel.setText("무승부입니다.");
    		Client.sendGameResult("draw");
    	} else {
    		isPlayerOneTurn = !isPlayerOneTurn;
    		statusLabel.setText((isPlayerOneTurn? Client.playerId: Client.enemyId)+"졌습니다.");
    	}
    }
    
    private void sendMove(int x, int y) {
    	try {
    		BufferedWriter bw = Client.bw;
    		if(bw!=null) {
    			bw.write("move:" + x + ":" +y);
    			bw.newLine();
    			bw.flush();
    		}
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public void markOpponentMove(int x, int y) {
    	if(buttons[x][y].getText().equals("")) {
    		buttons[x][y].setText("O");
    		this.isMyTurn = true;
    		statusLabel.setText("내 턴입니다.");
    		System.out.println("markOpponentMove 호출 됨");
    	}
    }

    public void updatePlayerPanels() {
    	playerInfoPanel.removeAll();
    	playerInfoPanel.add(createPlayerPanel(Client.playerId));
    	playerInfoPanel.add(createPlayerPanel(Client.enemyId));
    	playerInfoPanel.revalidate();
    	playerInfoPanel.repaint();
    }
    
    private JPanel createPlayerPanel(String playerId) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.decode("#FFE57F"));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel ratingLabel = new JLabel("9999", JLabel.CENTER); // 기본값
//        JLabel profileLabel = new JLabel(new ImageIcon("img/default.png")); //프로필(추후 변경)
        JLabel nameLabel = new JLabel(playerId, JLabel.CENTER);

        JLabel recordLabel = new JLabel("전적 불러오는 중", JLabel.CENTER);
        JLabel winRateLabel = new JLabel("승률 계산중", JLabel.CENTER);

        if (playerId!=null&&!playerId.equals("상대")) {
            List<String> userInfo = ConnectDb.map.get(playerId);
            if (userInfo != null) {
                int win = Integer.parseInt(userInfo.get(1));
                int draw = Integer.parseInt(userInfo.get(2));
                int lose = Integer.parseInt(userInfo.get(3));
                int rating = Integer.parseInt(userInfo.get(4));
                ratingLabel.setText(String.valueOf(rating));
                int total = win + lose + draw;
                int rate = total > 0 ? (int)(((double)win / total) * 100) : 0;
                recordLabel.setText(win + "승 " + draw + "무 " + lose + "패");
                winRateLabel.setText("승률 " + String.format("%03d", rate) + "%");
                System.out.println("내 ID"+Client.playerId+" 상대 ID "+Client.enemyId+"상대 전적"+ConnectDb.map.get(Client.enemyId));
//                profileLabel.setIcon(new ImageIcon("img/profile_" + rating / 1000 + ".png"));
            }else {
            	recordLabel.setText("전적 없음");
            	winRateLabel.setText("");
            }
        }

        ratingLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
//        profileLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        recordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        winRateLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(ratingLabel);
//        panel.add(profileLabel);
        panel.add(nameLabel);
        panel.add(recordLabel);
        panel.add(winRateLabel);

        return panel;
    }

    private boolean checkWin() {
        String symbol = isPlayerOneTurn ? "X" : "O";
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getText().equals(symbol) && buttons[i][1].getText().equals(symbol) && buttons[i][2].getText().equals(symbol)) return true;
            if (buttons[0][i].getText().equals(symbol) && buttons[1][i].getText().equals(symbol) && buttons[2][i].getText().equals(symbol)) return true;
        }
        if (buttons[0][0].getText().equals(symbol) && buttons[1][1].getText().equals(symbol) && buttons[2][2].getText().equals(symbol)) return true;
        if (buttons[0][2].getText().equals(symbol) && buttons[1][1].getText().equals(symbol) && buttons[2][0].getText().equals(symbol)) return true;
        return false;
    }

    private boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().equals("")) return false;
            }
        }
        return true;
    }

    private void disableBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(false);
            }
        }
    }

    private void sendMessage() {
        String msg = chatInput.getText().trim();
        if (!msg.isEmpty()) {
            Client.sendMessage(Client.playerId+":"+ msg);
            chatInput.setText("");
        }
    }

    public void appendChat(String msg) {
        chatArea.append(msg + "\n");
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// 오버라이드 되어있음
	}
	
	public void onGameEnd(String result) {
		//Client에서 결과 도착시 오버라이드
	}
}